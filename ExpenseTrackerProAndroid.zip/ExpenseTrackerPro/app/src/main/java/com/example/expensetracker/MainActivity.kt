package com.example.expensetracker
import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class Expense(val name:String,val amount:Int,val cat:String,val month:String)

class MainActivity:ComponentActivity(){
 override fun onCreate(savedInstanceState:Bundle?){
  super.onCreate(savedInstanceState)
  setContent{App()}
 }
}

fun save(ctx:Context,list:List<Expense>){
 val arr=JSONArray()
 list.forEach{
  val o=JSONObject()
  o.put("n",it.name);o.put("a",it.amount);o.put("c",it.cat);o.put("m",it.month)
  arr.put(o)
 }
 ctx.getSharedPreferences("exp",0).edit().putString("data",arr.toString()).apply()
}

fun load(ctx:Context):MutableList<Expense>{
 val s=ctx.getSharedPreferences("exp",0).getString("data","[]")!!
 val arr=JSONArray(s)
 val out= mutableListOf<Expense>()
 for(i in 0 until arr.length()){
  val o=arr.getJSONObject(i)
  out.add(Expense(o.getString("n"),o.getInt("a"),o.getString("c"),o.getString("m")))
 }
 return out
}

@Composable
fun App(){
 val ctx= LocalContext.current
 val month=SimpleDateFormat("yyyy-MM",Locale.getDefault()).format(Date())
 val data= remember { mutableStateListOf<Expense>().apply{ addAll(load(ctx)) } }
 var name by remember{ mutableStateOf("") }
 var amount by remember{ mutableStateOf("") }
 var cat by remember{ mutableStateOf("Primer") }
 var budget by remember{ mutableStateOf("3000000") }

 val monthly=data.filter{it.month==month}
 val total=monthly.sumOf{it.amount}
 val primer=monthly.filter{it.cat=="Primer"}.sumOf{it.amount}
 val sek=monthly.filter{it.cat=="Sekunder"}.sumOf{it.amount}

 MaterialTheme{
 Column(Modifier.padding(16.dp)){
  Text("Bulan: $month")
  Text("Total: Rp$total")
  Text("Primer: Rp$primer | Sekunder: Rp$sek")
  OutlinedTextField(budget,{budget=it},label={Text("Budget Bulanan")})
  Text("Sisa Budget: Rp${(budget.toIntOrNull()?:0)-total}")
  OutlinedTextField(name,{name=it},label={Text("Nama")})
  OutlinedTextField(amount,{amount=it},label={Text("Nominal")})
  Row{
   Button(onClick={cat="Primer"}){Text("Primer")}
   Spacer(Modifier.width(8.dp))
   Button(onClick={cat="Sekunder"}){Text("Sekunder")}
  }
  Button(onClick={
   val a=amount.toIntOrNull()?:0
   if(name.isNotBlank()&&a>0){
    data.add(Expense(name,a,cat,month))
    save(ctx,data)
    name="";amount=""
   }
  }){Text("Tambah")}
  LazyColumn{
   itemsIndexed(monthly){idx,item->
    Row(Modifier.fillMaxWidth(), horizontalArrangement=Arrangement.SpaceBetween){
      Text("${item.name} Rp${item.amount} (${item.cat})")
      TextButton(onClick={
        val realIndex=data.indexOf(item)
        if(realIndex>=0){ data.removeAt(realIndex); save(ctx,data)}
      }){Text("Hapus")}
    }
   }
  }
 }
 }
}