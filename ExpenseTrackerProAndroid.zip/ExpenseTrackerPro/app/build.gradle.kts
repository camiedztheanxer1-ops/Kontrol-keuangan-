plugins{
 id("com.android.application")
 id("org.jetbrains.kotlin.android")
}
android{
 namespace="com.example.expensetracker"
 compileSdk=34
 defaultConfig{
  applicationId="com.example.expensetracker"
  minSdk=24
  targetSdk=34
 }
 buildFeatures{ compose=true }
 composeOptions{ kotlinCompilerExtensionVersion="1.5.14" }
}
dependencies{
 implementation("androidx.activity:activity-compose:1.9.0")
 implementation("androidx.compose.material3:material3:1.2.1")
 implementation("androidx.compose.ui:ui:1.6.7")
 implementation("androidx.compose.ui:ui-tooling-preview:1.6.7")
 implementation("androidx.compose.runtime:runtime-saveable:1.6.7")
}