Fitur:
- Simpan data permanen
- Primer / Sekunder
- Total bulanan
- Budget bulanan + sisa budget
- Hapus transaksi
Buka dengan Android Studio lalu Run.